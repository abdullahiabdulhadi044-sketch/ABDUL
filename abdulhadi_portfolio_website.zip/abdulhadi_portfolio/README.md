# Abdulhadi Abdullahi — Portfolio Website

A responsive personal portfolio built with plain HTML, CSS and JavaScript.

## Files
- `index.html` — website content and sections
- `style.css` — layout, colours, responsive styling and animations
- `script.js` — mobile navigation, scroll progress and reveal effects

## Before publishing
1. Open `index.html`.
2. Find `your.email@example.com` and replace it with your real email address.
3. Review your name, skills, project descriptions and location. Edit any details you want to change.
4. Save all files.

## Publish with GitHub Pages
1. Create a new repository on GitHub (for example, `my-portfolio`).
2. Upload `index.html`, `style.css`, `script.js` and `README.md` to the repository's root.
3. Open the repository's **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**.
5. Select branch **main** and folder **/(root)**, then click **Save**.
6. Wait a few minutes. GitHub will show your published website address in the Pages section.

No build tools or frameworks are required. Google Fonts needs an internet connection; the site otherwise uses local files.
